clear all;
clc;

SearchAgents_no = 100;     % Population size
Max_evaluations = 100000;     % Max number of objective evaluations 

Function_name = sprintf('F%d', 1);

% Objective
fobj = @Chung_Reynolds;

% Problem setting
dim = 100;
lb = -100 * ones(1, dim);
ub =  100 * ones(1, dim);

% Run
[Best_score, Best_pos, Q_ENRIME_curve] = Q_ENRIME(SearchAgents_no, Max_evaluations, lb, ub, dim, fobj);

disp(['Best_score = ', num2str(Best_score)]);

