function objval = Chung_Reynolds(x)
% Chung-Reynolds function
% Usually: x in [-100,100] (you set it so)
% f(x) = sum_{i=1}^n (x_i^2)^2 = sum x_i^4

    x = x(:).';           % ensure row vector
    objval = sum(x.^4);
end
