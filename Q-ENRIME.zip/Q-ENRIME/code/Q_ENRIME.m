function [Best_rime_rate, Best_rime, Convergence_curve] = Q_ENRIME(N, Max_evaluations, lb, ub, dim, fobj)
% Q_ENRIME ：
%
% Inputs:
%   N               - population size
%   Max_evaluations - maximum objective evaluations 
%   lb, ub          - scalar or 1xdim bound vectors
%   dim             - dimension
%   fobj            - objective function handle
%
% Outputs:
%   Best_rime_rate    - best fitness found
%   Best_rime         - best solution vector
%   Convergence_curve - best fitness recorded per generation 

    % ---------------- basic checks ----------------
    if Max_evaluations < 1
        error('Max_evaluations must be >= 1.');
    end
    if isscalar(lb), lb = lb * ones(1, dim); end
    if isscalar(ub), ub = ub * ones(1, dim); end
    lb = reshape(lb, 1, dim);
    ub = reshape(ub, 1, dim);

    % ---------------- initialization (ALHS) ----------------
    total_evaluations = 0;
    [Rimepop, Rime_rates, total_evaluations] = ALHSInitialization( ...
        N, dim, lb, ub, fobj, total_evaluations, Max_evaluations);

    if isempty(Rimepop) || isempty(Rime_rates)
        Best_rime_rate = inf;
        Best_rime = nan(1, dim);
        Convergence_curve = Best_rime_rate;
        return;
    end

    % Global best
    [Best_rime_rate, best_idx] = min(Rime_rates);
    Best_rime = Rimepop(best_idx, :);

    % Convergence (per generation)
    Convergence_curve = Best_rime_rate;

    % ---------------- main loop ----------------
    xi = 5; 

    remaining = Max_evaluations - total_evaluations;
    Tmax_est = max(1, floor(remaining / max(1, N)));

    t = 0; 

    while total_evaluations < Max_evaluations

      tau = min(1, t / Tmax_est);

        % ---- hyperparameters (Eq.3) ----
        [theta_env, beta_env, E] = RIMEHyperparams_tau(tau, xi);

        % ---- normalized fitness for hard puncture (Eq.4) ----
        fnorm = NormalizedFitnessForHardRime_m11(Rime_rates); % in [-1,1]

        for i = 1:N
            if total_evaluations >= Max_evaluations
                break;
            end

            parent = Rimepop(i, :);
            offspring = parent;

            for j = 1:dim
                % -------- Soft rime ice search (Eq.2) --------
                r2 = rand; 
                if r2 < E
                    r1 = -1 + 2*rand; 
                    h  = rand;       
                    rand_pos = h * (ub(j) - lb(j)) + lb(j);
                    offspring(j) = Best_rime(j) + r1 * cos(theta_env) * beta_env * rand_pos;
                end

                % -------- Hard rime ice puncture (Eq.4) --------
                r3 = -1 + 2*rand;     
                if r3 < fnorm(i)
                    offspring(j) = Best_rime(j);
                end
            end

            % Bounds
            offspring = max(min(offspring, ub), lb);

            new_fit = fobj(offspring);
            total_evaluations = total_evaluations + 1;

            % -------- ASM selection (Eq.8-11) --------
            Dis_i  = sum(abs(parent - offspring));          % Eq.(8)
            DeltaF = abs(new_fit - Rime_rates(i));          % Eq.(9)
            p_i    = exp( - DeltaF / (Dis_i + eps) );       % Eq.(10)

            if (new_fit < Rime_rates(i)) || (rand < p_i)    % Eq.(11)
                Rimepop(i, :) = offspring;
                Rime_rates(i) = new_fit;

                if new_fit < Best_rime_rate
                    Best_rime_rate = new_fit;
                    Best_rime = offspring;
                end
            end
        end

        if total_evaluations >= Max_evaluations
            break;
        end

        % ---------------- QELS activation----------------
        if t > 0.75 * Tmax_est
            [Rimepop, Rime_rates, Best_rime_rate, Best_rime, total_evaluations] = QELS_PaperBudget( ...
                Rimepop, Rime_rates, Best_rime, Best_rime_rate, lb, ub, fobj, total_evaluations, Max_evaluations);
        end

        % Record convergence after one generation
        Convergence_curve(end+1) = Best_rime_rate; %#ok<AGROW>

        t = t + 1;
    end
end

% ======================================================================
% Subfunctions
% ======================================================================

function [R, F, total_evals] = ALHSInitialization(N, dim, lb, ub, fobj, total_evals, Max_evals)
% ALHS initialization :
%   1) LHS -> scale to [lb,ub]
%   2) Eq.(6) density adjustment: R_adj = R + eta*(UB-LB), eta_i = F_i / max(F)
%   3) Eq.(7) Gaussian perturbation: R_final = R_adj + u*N(0,sigma), sigma=(UB-LB)/N
%      At initialization, t=0 -> u = 0.1 + 0.9*(t/Tmax) = 0.1
%   4) clip to bounds, evaluate final population

    R = [];
    F = [];

    % --- LHS ---
    try
        R = lhsdesign(N, dim, 'criterion', 'maximin'); % [0,1]
    catch
        R = rand(N, dim);
    end
    R = lb + (ub - lb) .* R;

    % Evaluate fitness on LHS population (for Eq.6)
    F = inf(1, N);
    for i = 1:N
        if total_evals >= Max_evals
            R = [];
            F = [];
            return;
        end
        F(i) = fobj(R(i, :));
        total_evals = total_evals + 1;
    end

    % --- Eq.(6): eta_i = F_i / max(F) ---
    finite = isfinite(F);
    if any(finite)
        Fmax = max(F(finite));
        if abs(Fmax) < eps
            eta = zeros(N,1);
        else
            eta = (F(:) ./ Fmax);     % Nx1
            eta(~finite) = 0;
        end
        R = R + eta .* (ub - lb);
        R = max(min(R, ub), lb);
    end

    % --- Eq.(7): Gaussian perturbation ---
    u = 0.1;
    sigma = (ub - lb) / N;            % 1xdim (std)
    R = R + u .* randn(N, dim) .* sigma;
    R = max(min(R, ub), lb);

    % Evaluate final initialized population
    F = inf(1, N);
    for i = 1:N
        if total_evals >= Max_evals
            R = [];
            F = [];
            return;
        end
        F(i) = fobj(R(i, :));
        total_evals = total_evals + 1;
    end
end

function [theta, beta, E] = RIMEHyperparams_tau(tau, xi)
%   theta = pi*tau/10
%   beta  = 1 - round(xi*tau)/xi
%   E     = sqrt(tau)

    tau = max(0, min(1, tau));
    theta = pi * tau / 10;
    beta  = 1 - round(xi * tau) / xi;
    beta  = max(0, beta);
    E     = sqrt(tau);
end

function fnorm = NormalizedFitnessForHardRime_m11(F)
    fnorm = zeros(size(F));
    finite = isfinite(F);
    if ~any(finite), return; end

    Fmin = min(F(finite));
    Fmax = max(F(finite));

    if abs(Fmax - Fmin) < eps
        fnorm(:) = 0;  % neutral
        return;
    end

    s = (F - Fmin) ./ (Fmax - Fmin);
    s(~finite) = 0;
    fnorm = 2*s - 1;
    fnorm = max(-1, min(1, fnorm));
end

function [R, F, Best_val, Best_pos, total_evals] = QELS_PaperBudget(R, F, Best_pos, Best_val, lb, ub, fobj, total_evals, Max_evals)
% For each elite individual:
%   Stage 1: Eq.(12) quantum variation with prob pm
%   Stage 2: Eq.(13) quantum gate (always)
%   Stage 3: Eq.(14) dynamic phase rotation (always)

    [N, dim] = size(R);

    pm = 0.8;
    lambda = 0.05;

    elite_num = max(1, round(0.1 * N));
    [~, order] = sort(F, 'ascend');
    elite_idx = order(1:elite_num);

    range = (ub - lb);

    for k = 1:numel(elite_idx)
        idx = elite_idx(k);

        if total_evals >= Max_evals, return; end

        base = R(idx, :);

        % ---------------- Stage 1: Eq.(12) Quantum variation ----------------
        if rand < pm
            DeltaR = lambda * range;
            cand = base + DeltaR .* ((-1 + 2*rand(1, dim)) .* randn(1, dim));
            cand = max(min(cand, ub), lb);

            new_fit = fobj(cand);
            total_evals = total_evals + 1;

            if new_fit < F(idx)
                R(idx, :) = cand;
                F(idx) = new_fit;
                base = cand; % update base for next stages
                if new_fit < Best_val
                    Best_val = new_fit;
                    Best_pos = cand;
                end
            end

            if total_evals >= Max_evals, return; end
        end

        % ---------------- Stage 2: Eq.(13) Quantum gate ----------------
        theta = pi * rand; % scalar in (0,pi)
        cand = base * cos(theta) + Best_pos * sin(theta);
        cand = max(min(cand, ub), lb);

        new_fit = fobj(cand);
        total_evals = total_evals + 1;

        if new_fit < F(idx)
            R(idx, :) = cand;
            F(idx) = new_fit;
            base = cand;
            if new_fit < Best_val
                Best_val = new_fit;
                Best_pos = cand;
            end
        end

        if total_evals >= Max_evals, return; end

        % ---------------- Stage 3: Eq.(14) Dynamic quantum phase rotation ----------------
        theta = pi * rand;     % scalar in (0,pi)
        phi   = 2*pi * rand;   % scalar in (0,2pi)
        cand  = base * cos(theta) + Best_pos * sin(theta) * cos(phi);
        cand  = max(min(cand, ub), lb);

        new_fit = fobj(cand);
        total_evals = total_evals + 1;

        if new_fit < F(idx)
            R(idx, :) = cand;
            F(idx) = new_fit;
            if new_fit < Best_val
                Best_val = new_fit;
                Best_pos = cand;
            end
        end
    end
end
