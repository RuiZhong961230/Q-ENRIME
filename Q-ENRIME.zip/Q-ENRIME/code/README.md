# Q-ENRIME — Multi-Strategy Quantum-Enhanced RIME Algorithm

> **Multi-Strategy Quantum-Enhanced RIME Algorithm (Q-ENRIME)** for robust global optimization, with a focus on efficiently solving **underdetermined systems of equations** arising in **grounding network corrosion diagnosis**.

---

## 1. Motivation

Grounding network corrosion diagnosis can be formulated via electrical network theory, but practical measurement-node limitations frequently lead to a **challenging underdetermined (often nonlinear) system of equations**, where traditional analytical or gradient-based methods may struggle with convergence, multimodality, and pathological solution landscapes.

This repository provides an implementation of **Q-ENRIME**, a strengthened variant of the RIME metaheuristic that improves:
- **initial population coverage** (better exploration start),
- **diversity preservation** (less premature convergence),
- **late-stage exploitation accuracy** (better final precision).

---

## 2. Key Features (What’s New)

Q-ENRIME integrates three core strategies:

### (1) ALHS — Adaptive Latin Hypercube Sampling (Initialization)
A refined LHS scheme that improves initial coverage and adaptively perturbs samples to avoid poor regions early.

### (2) ASM — Adaptive Selection Mechanism (Diversity + Efficiency)
A probabilistic acceptance rule that jointly considers:
- **Manhattan distance** (diversity / step size),
- **fitness difference** (solution quality change),
to balance exploration and exploitation dynamically.

### (3) QELS — Quantum-Enhanced Local Search (Late-stage Refinement)
Activated in the **late optimization phase** (e.g., after 0.75·Tmax), applied to elite individuals to boost precision using quantum-inspired operators (mutation + rotation-gate style combination + phase rotation).

---

## 3. Algorithm Overview

High-level flow:

1. **Initialize** population with **ALHS**
2. Iterate until `t = Tmax`:
   - Generate offspring using RIME search operators
   - Apply **ASM** to accept/reject offspring (diversity-aware)
   - If late-stage: apply **QELS** on elite subset
3. Return best solution found

---



